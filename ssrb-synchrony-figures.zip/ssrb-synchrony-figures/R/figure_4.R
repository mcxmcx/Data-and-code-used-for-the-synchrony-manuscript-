# Matched-period river-lake comparison, 1994-2009.
library(ggplot2)
source("R/synchrony.R")
water <- water_pairs(1994, 2009)
write_table(water, "figure_4_water_pairs")
hydro <- read.csv("data/reference/figure4_hydroclimate.csv")
lake <- read.csv("data/reference/lake_benchmarks.csv")

climate_sites <- read.csv("metadata/climate_stations.csv")$site
hydro_pairs <- lapply(seq_len(nrow(hydro)), function(i) {
  obs <- read.csv(file.path("data/hydroclimate", hydro$file[i]))
  month <- substr(obs$Time, 1, 7)
  stopifnot(!anyDuplicated(month))
  values <- obs[month >= "1994-01" & month <= "2009-12", -1, drop = FALSE]
  if (hydro$variable[i] == "Flow") {
    names(values) <- sub("^O_", "OM_", sub("^R_", "RD_", names(values)))
    stopifnot(setequal(names(values), river_sites))
  } else {
    stopifnot(setequal(names(values), climate_sites))
  }
  correlate_sites(values, hydro$variable[i])
})
hydro_pairs <- do.call(rbind, hydro_pairs)
write_table(hydro_pairs, "figure_4_hydroclimate_pairs")
audit <- merge(hydro, mean_synchrony(hydro_pairs), by = "variable", sort = FALSE)
names(audit)[names(audit) == "S_river"] <- "S_recalculated"
# A second discharge file used in the project has no measurements during 2009.
# Record its estimate alongside the one calculated from the longer station series.
short_flow <- read.csv("data/reference/discharge_matched_archive.csv")
short_flow <- short_flow[substr(short_flow$Time, 1, 7) >= "1994-01" &
                         substr(short_flow$Time, 1, 7) <= "2009-12", ]
audit$S_short_discharge_file <- NA_real_
audit$S_short_discharge_file[audit$variable == "Flow"] <-
  mean_synchrony(correlate_sites(short_flow[-1], "Flow"))$S_river
write_table(audit, "figure_4_hydroclimate_audit")

river <- rbind(mean_synchrony(water), mean_synchrony(hydro_pairs))
contrast <- merge(river, lake, by = "variable", all.x = TRUE)
names(contrast)[names(contrast) == "S_river"] <- "S_recalculated"
contrast$S_manuscript <- contrast$S_recalculated
idx <- match(hydro$variable, contrast$variable)
contrast$S_manuscript[idx] <- hydro$S_plotted
contrast$delta_manuscript <- contrast$S_manuscript - contrast$S_lake
contrast$delta_recalculated <- contrast$S_recalculated - contrast$S_lake
stopifnot(nrow(contrast) == 19, sum(is.finite(contrast$S_lake)) == 13)

climate <- c("AT", "PCPN", "Wind")
aquatic <- contrast[!contrast$variable %in% climate, ]
order4 <- c(climate, aquatic$variable[order(aquatic$S_manuscript, decreasing = TRUE)])
contrast <- contrast[match(order4, contrast$variable), ]
write_table(contrast, "figure_4_contrasts")
labels <- c(setNames(variables$label_figure4, variables$variable),
            AT = "AT", PCPN = "PCPN", Wind = "Wind", Flow = "Flow")

draw_comparison <- function(data, river_column) {
  data$x <- seq_len(nrow(data))
  data$river <- data[[river_column]]
  matched <- data[is.finite(data$S_lake), ]
  matched$direction <- ifelse(matched$river > matched$S_lake, "down", "up")
  # Arrowheads point toward the lake, leaving space for its symbol. Positive delta means the river value is higher.
  gap <- pmin(0.024, abs(matched$river - matched$S_lake) / 3)
  matched$tip <- matched$S_lake + sign(matched$river - matched$S_lake) * gap
  points <- rbind(data.frame(x = data$x, S = data$river, system = "Rivers"),
                  data.frame(x = matched$x, S = matched$S_lake, system = "Lakes"))
  ggplot() +
    geom_vline(xintercept = 3.5, linetype = "dashed", colour = "#CA5600", linewidth = 0.5) +
    annotate("segment", x = 1, xend = 3.44, y = 1.055, yend = 1.055, colour = "#CA5600") +
    annotate("text", x = 2.15, y = 1.095, label = "Climate variables", colour = "#B65300",
             size = 3.1, fontface = "bold") +
    geom_segment(data = matched, aes(x = x, xend = x, y = river, yend = tip,
                                     colour = direction),
                 arrow = grid::arrow(length = grid::unit(1.9, "mm"), type = "closed"),
                 linewidth = 0.65, show.legend = FALSE) +
    geom_point(data = points, aes(x, S, fill = system), shape = 21,
               colour = "black", size = 3, stroke = 0.55) +
    scale_fill_manual(values = c(Lakes = "#E41A1C", Rivers = "#377EB8")) +
    scale_colour_manual(values = c(down = "#7435A7", up = "#79B942")) +
    scale_x_continuous(breaks = data$x, labels = unname(labels[data$variable]),
                       limits = c(0.45, 19.55), expand = c(0, 0)) +
    scale_y_continuous(breaks = seq(0.25, 1, 0.25), labels = function(x) sprintf("%.2f", x)) +
    coord_cartesian(ylim = c(0.08, 1.045), clip = "off", expand = FALSE) +
    labs(x = NULL, y = expression("Synchrony (" * italic(S) * ")"), fill = NULL) +
    theme_bw(base_size = 13) +
    theme(panel.grid = element_blank(), axis.text.x = element_text(angle = 90, hjust = 1, vjust = 0.5),
          legend.position = "inside", legend.position.inside = c(0.88, 0.86),
          legend.background = element_blank(), plot.margin = margin(18, 5, 5, 5))
}
save_figure(draw_comparison(contrast, "S_manuscript"), "figure_4_manuscript", 114)
save_figure(draw_comparison(contrast, "S_recalculated"), "figure_4_recalculated", 114)
