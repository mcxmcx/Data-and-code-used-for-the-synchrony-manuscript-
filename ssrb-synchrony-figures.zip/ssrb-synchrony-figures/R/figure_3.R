# Pairwise water-quality synchrony across nine river sites, 1983-2023.
library(ggplot2)
source("R/synchrony.R")
pairs <- water_pairs(1983, 2023)
means <- mean_synchrony(pairs)
stopifnot(nrow(pairs) == 15 * choose(9, 2), all(is.finite(pairs$r)))
write_table(pairs, "figure_3_pairs")
write_table(means, "figure_3_means")

labels <- setNames(variables$label_figure3, variables$variable)
p <- ggplot(pairs, aes(variable, r)) +
  geom_hline(yintercept = 0, linetype = "dashed", colour = "#CA5600", linewidth = 0.45) +
  geom_point(position = position_jitter(width = 0.10, height = 0, seed = 3403),
             shape = 21, fill = "grey70", colour = "grey20",
             size = 1.65, stroke = 0.5, alpha = 0.78) +
  geom_boxplot(width = 0.45, coef = 1.5, outlier.shape = NA, fill = "#E8E3D3",
               alpha = 0.94, linewidth = 0.45) +
  geom_point(data = means, aes(y = S_river), shape = 23,
             fill = "#6B4636", colour = "black", size = 2.5, stroke = 0.4) +
  scale_x_discrete(limits = variables$variable, labels = labels) +
  scale_y_continuous(expand = c(0, 0), breaks = seq(0, 1, 0.25), labels = function(x) sprintf("%.2f", x)) +
  coord_cartesian(ylim = c(-0.17, 1.07)) +
  labs(x = NULL, y = expression("Pairwise Pearson correlation (" * italic(r) * ")")) +
  theme_bw(base_size = 13) +
  theme(panel.grid = element_blank(), axis.text.x = element_text(angle = 90, hjust = 1, vjust = 0.5))
save_figure(p, "figure_3", 98)
