# Run with Rscript --vanilla run_all.R from the extracted repository root.
required <- c("ggplot2", "ragg")
missing <- required[!vapply(required, requireNamespace, logical(1), quietly = TRUE)]
if (length(missing)) stop("Install the following R packages: ", paste(missing, collapse = ", "))
if (packageVersion("ggplot2") < "3.5.0") stop("ggplot2 3.5.0 or newer is required.")
source("R/figure_3.R", local = new.env())
source("R/figure_4.R", local = new.env())
message("Figures and numerical results have been written to figures/ and results/.")
