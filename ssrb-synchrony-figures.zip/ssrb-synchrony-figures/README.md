# River and lake synchrony in the Canadian Prairies

Data and R code for Figures 3 and 4 of *Comparison of river and lake synchrony using the Energy-mass flux framework*, by Chenxi Mi and colleagues. The river network comprises nine mainstem stations on the Bow, Oldman and Red Deer rivers in the South Saskatchewan River Basin (SSRB). The lake comparison uses published estimates for the Qu’Appelle system.

| Figure | Period | Analysis and figure |
| --- | --- | --- |
| 3 | 1983–2023 | [Station-pair correlations and network means](figures/figure_3.png) for 15 water-quality variables. Each brown diamond denotes the arithmetic mean of up to 36 pairwise Pearson correlations. All 36 pairs are estimable for each variable. |
| 4 | 1994–2009 comparison window | [Manuscript reconstruction](figures/figure_4_manuscript.png) and [recalculation from the archived station records](figures/figure_4_recalculated.png). Arrows run from the river estimate to the paired lake benchmark. River-only variables have no lake estimate or contrast. |

## Reproduce the figures

Extract the archive or clone the repository. From its root directory, install the two packages once and run the analysis:

```sh
Rscript -e "install.packages(c('ggplot2', 'ragg'), repos='https://cloud.r-project.org')"
Rscript --vanilla run_all.R
```

In RStudio, open the extracted directory as a project, or set it as the working directory, then run `source("run_all.R")`. Each figure can also be run independently with `Rscript --vanilla R/figure_3.R` or `Rscript --vanilla R/figure_4.R`. The analysis runs offline after installation. Tested with R 4.5.2, ggplot2 4.0.2 and ragg 1.5.0. The plotting code requires ggplot2 3.5.0 or later.

## How synchrony is calculated

For each water-quality variable and time window, average measurements within each station and calendar month. For each distinct pair of stations, align the two series by year and month. Compute Pearson's *r* when at least three finite matched observations exist and both series vary. Missing months are left missing. The network statistic *S* is the unweighted arithmetic mean of estimable pairwise correlations. Linear standardization within each site leaves these correlations unchanged.

Figure 3 displays the individual coefficients, median, interquartile range and whiskers to the most extreme observations within 1.5 interquartile ranges of the box. The seeded horizontal jitter preserves each point’s correlation value. Figure 4 repeats the river analysis within the comparison window and joins the estimates to the 1994–2009 lake benchmarks. The descriptive contrast is river *S* minus lake *S*.

## Reading Figure 4

The two outputs document differences between the revised artwork and the available hydroclimate inputs. Both use the same recalculated water-quality estimates and the same published lake values. The manuscript reconstruction uses the archived plotting values for air temperature, precipitation and wind, and the two-decimal discharge value represented in the embedded figure. The independent recalculation uses the station observations for all four. The 1994–2009 river analysis script specifies discharge as 0.76, as does the manuscript text.

| SSRB variable | Revised artwork | Recalculated from available months |
| --- | ---: | ---: |
| Air temperature | 0.99 | 0.99088 |
| Precipitation | 0.76 | 0.72097 |
| Wind speed | 0.59 | 0.59777 |
| Discharge | approximately 0.79 | 0.76025 |

The project’s monthly climate and discharge series begin in January 1995. Coverage varies among stations. Only 10 of the 15 climate-station pairs have overlapping wind measurements in the comparison window. The primary discharge recalculation uses available 1995–2009 records from the longer monthly archive. A separate file labelled 1994–2009 contains discharge observations only through December 2008 and yields 0.75854. Both discharge estimates round to 0.76. The comparison directions for these variables agree across the two figure versions. [Numerical audit](results/figure_4_hydroclimate_audit.csv)

## Data and provenance

- **River water quality.** The 15 CSVs in [data/water_quality](data/water_quality) are the project's cleaned, dated monitoring observations used as the analysis inputs. Columns are `site`, `date` and `Variable`. The scripts select the nine study stations and the relevant dates. Parameter definitions, units and figure labels are listed in the [variable dictionary](metadata/water_quality_variables.csv). The [station crosswalk](metadata/river_stations.csv) includes provincial IDs, station-specific portal links and the corresponding hydrometric gauge IDs. Original monitoring records and sampling metadata are available through the [Alberta Water Quality Data Portal](https://environment.extranet.gov.ab.ca/apps/WaterQuality/dataportal/).
- **Hydroclimate.** Each [monthly input](data/hydroclimate) has a month column (`Time`) followed by station columns. Air temperature is the monthly mean of daily mean temperature (°C), precipitation is the monthly mean of available daily precipitation totals (mm per observed day), wind is monthly mean wind speed (km/h), and discharge is monthly mean flow (m³/s). The analysis uses archived monthly values. Original daily or hourly records can be retrieved from [ECCC Historical Climate Data](https://climate.weather.gc.ca/) and [Water Survey of Canada](https://wateroffice.ec.gc.ca/search/historical_e.html). See the [six climate stations](metadata/climate_stations.csv). The hydrometric column prefixes B, O and R denote the Bow, Oldman and Red Deer rivers.
- **Lake benchmarks.** The 13 values in [lake_benchmarks.csv](data/reference/lake_benchmarks.csv) were transcribed from Vogt, Rusak, Patoine & Leavitt (2011), *Ecology* 92, 1104–1114, Appendix A, Table A1 (1994–2009). The table preserves the original source terms. In the manuscript comparison, river conductivity is paired with lake salinity, river nitrate plus nitrite with lake nitrate, and river ammonia nitrogen with lake ammonium. These are operational comparisons. The lake input consists of published summary statistics. [Archived Appendix A](https://doi.org/10.6084/m9.figshare.3551241.v1)

## Repository contents

| Path | Contents |
| --- | --- |
| [R/figure_3.R](R/figure_3.R), [R/figure_4.R](R/figure_4.R) | Figure-specific analysis and plotting code |
| [R/synchrony.R](R/synchrony.R) | Station-month matching, pairwise correlations and output functions |
| [data](data), [metadata](metadata) | Analysis inputs, benchmark values, units and station identifiers |
| [figures](figures) | Publication-scale vector PDFs and 450-dpi PNG previews |
| [results](results) | Site-pair overlap counts and coefficients, variable means, paired contrasts and hydroclimate audit |

The water-quality workflow follows the project scripts *EL_synchrony_metric_robustness.R*, *Pairwise S plot.R* and *Calculate S (1994-2009).R*. The zero reference line in Figure 3 and the arrows and climate grouping in Figure 4 follow the revised manuscript artwork. Graphic layout and horizontal jitter have been regenerated for reproducibility.

Questions about the analysis may be directed to Chenxi Mi (cxmi@niglas.ac.cn).
