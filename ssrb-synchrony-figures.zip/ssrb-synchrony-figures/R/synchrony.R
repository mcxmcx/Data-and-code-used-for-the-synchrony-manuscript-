# Common analysis for Figures 3 and 4. Run from the repository root.
if (!file.exists("metadata/water_quality_variables.csv")) {
  stop("Run the analysis from the extracted repository root.", call. = FALSE)
}
variables <- read.csv("metadata/water_quality_variables.csv")
river_sites <- read.csv("metadata/river_stations.csv", fileEncoding = "UTF-8-BOM")$site
dir.create("results", showWarnings = FALSE)
dir.create("figures", showWarnings = FALSE)

# Each pair uses its own overlapping months. Equal weights are applied to
# estimable correlations when computing S, regardless of the overlap count.
correlate_sites <- function(values, variable) {
  pairs <- combn(names(values), 2)
  rows <- lapply(seq_len(ncol(pairs)), function(i) {
    sites <- pairs[, i]
    x <- values[[sites[1]]]
    y <- values[[sites[2]]]
    ok <- is.finite(x) & is.finite(y)
    n <- sum(ok)
    r <- NA_real_
    if (n >= 3 && sd(x[ok]) > 0 && sd(y[ok]) > 0) {
      r <- cor(x[ok], y[ok], method = "pearson")
    }
    data.frame(variable = variable, site1 = sites[1], site2 = sites[2], n = n, r = r)
  })
  do.call(rbind, rows)
}

water_pairs <- function(first_year, last_year) {
  results <- lapply(seq_len(nrow(variables)), function(i) {
    obs <- read.csv(file.path("data/water_quality", variables$file[i]))
    dates <- as.Date(obs$date)
    stopifnot(!anyNA(dates), is.numeric(obs$Variable))
    years <- as.integer(format(dates, "%Y"))
    obs$month <- format(dates, "%Y-%m")
    obs <- obs[obs$site %in% river_sites & years >= first_year & years <= last_year, ]
    stopifnot(setequal(obs$site, river_sites))
    monthly <- aggregate(Variable ~ month + site, obs, mean, na.action = na.omit)
    wide <- reshape(monthly, idvar = "month", timevar = "site", direction = "wide")
    values <- wide[paste0("Variable.", river_sites)]
    names(values) <- river_sites
    correlate_sites(values, variables$variable[i])
  })
  do.call(rbind, results)
}

mean_synchrony <- function(pairs) {
  means <- aggregate(r ~ variable, pairs, mean, na.action = na.omit)
  names(means)[2] <- "S_river"
  means
}

write_table <- function(x, name) {
  write.csv(x, file.path("results", paste0(name, ".csv")), row.names = FALSE, na = "NA")
}

save_figure <- function(plot, name, height) {
  ggplot2::ggsave(file.path("figures", paste0(name, ".png")), plot = plot,
                  device = ragg::agg_png, width = 180, height = height,
                  units = "mm", dpi = 450, bg = "white")
  ggplot2::ggsave(file.path("figures", paste0(name, ".pdf")), plot = plot,
                  device = grDevices::pdf, width = 180, height = height,
                  units = "mm", useDingbats = FALSE, bg = "white")
}
